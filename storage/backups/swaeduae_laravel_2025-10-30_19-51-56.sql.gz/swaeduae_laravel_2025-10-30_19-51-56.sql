--
-- PostgreSQL database dump
--

\restrict WYeH7D1CcnEEjccOWFpfonafWrMKOT1FZdizyYSTgzHV59voTQ6GXRVBuXFbEK9

-- Dumped from database version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: announcements; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.announcements (
    id bigint NOT NULL,
    event_id bigint,
    organization_id bigint,
    created_by bigint,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    type character varying(255) DEFAULT 'general'::character varying NOT NULL,
    is_published boolean DEFAULT false NOT NULL,
    published_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.announcements OWNER TO swaeduae_user;

--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.announcements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.announcements_id_seq OWNER TO swaeduae_user;

--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: applications; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.applications (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    event_id bigint NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    motivation text,
    skills json,
    availability json,
    experience text,
    custom_responses json,
    documents json,
    rejection_reason text,
    applied_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    reviewed_at timestamp(0) without time zone,
    reviewed_by bigint,
    attended boolean DEFAULT false NOT NULL,
    checked_in_at timestamp(0) without time zone,
    checked_out_at timestamp(0) without time zone,
    hours_completed numeric(5,2),
    rating integer,
    feedback text,
    volunteer_feedback text,
    volunteer_rating integer,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT applications_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying, 'waitlisted'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.applications OWNER TO swaeduae_user;

--
-- Name: applications_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.applications_id_seq OWNER TO swaeduae_user;

--
-- Name: applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.applications_id_seq OWNED BY public.applications.id;


--
-- Name: attendances; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.attendances (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    event_id bigint NOT NULL,
    application_id bigint NOT NULL,
    checked_in_at timestamp(0) without time zone,
    checkin_latitude numeric(10,8),
    checkin_longitude numeric(11,8),
    checkin_qr_code character varying(255),
    checkin_device_info character varying(255),
    checkin_notes text,
    checked_out_at timestamp(0) without time zone,
    checkout_latitude numeric(10,8),
    checkout_longitude numeric(11,8),
    checkout_qr_code character varying(255),
    checkout_device_info character varying(255),
    checkout_notes text,
    is_valid_checkin boolean DEFAULT true NOT NULL,
    is_valid_checkout boolean DEFAULT true NOT NULL,
    distance_from_event numeric(8,2),
    total_hours integer,
    actual_hours numeric(5,2),
    status character varying(255) DEFAULT 'checked_in'::character varying NOT NULL,
    verified_by_organizer boolean DEFAULT false NOT NULL,
    verified_by bigint,
    verified_at timestamp(0) without time zone,
    verification_notes text,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT attendances_status_check CHECK (((status)::text = ANY ((ARRAY['checked_in'::character varying, 'checked_out'::character varying, 'no_show'::character varying, 'late'::character varying, 'early_departure'::character varying])::text[])))
);


ALTER TABLE public.attendances OWNER TO swaeduae_user;

--
-- Name: attendances_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.attendances_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attendances_id_seq OWNER TO swaeduae_user;

--
-- Name: attendances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.attendances_id_seq OWNED BY public.attendances.id;


--
-- Name: badge_progress; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.badge_progress (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    badge_id bigint NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.badge_progress OWNER TO swaeduae_user;

--
-- Name: badge_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.badge_progress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.badge_progress_id_seq OWNER TO swaeduae_user;

--
-- Name: badge_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.badge_progress_id_seq OWNED BY public.badge_progress.id;


--
-- Name: badges; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.badges (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text NOT NULL,
    icon character varying(255),
    color character varying(255) DEFAULT '#3B82F6'::character varying NOT NULL,
    type character varying(255) DEFAULT 'achievement'::character varying NOT NULL,
    criteria json NOT NULL,
    points integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT badges_type_check CHECK (((type)::text = ANY ((ARRAY['hours'::character varying, 'events'::character varying, 'category'::character varying, 'special'::character varying, 'achievement'::character varying])::text[])))
);


ALTER TABLE public.badges OWNER TO swaeduae_user;

--
-- Name: badges_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.badges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.badges_id_seq OWNER TO swaeduae_user;

--
-- Name: badges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.badges_id_seq OWNED BY public.badges.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache OWNER TO swaeduae_user;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO swaeduae_user;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    icon character varying(255),
    color character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.categories OWNER TO swaeduae_user;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO swaeduae_user;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: certificates; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.certificates (
    id bigint NOT NULL,
    certificate_number character varying(255) NOT NULL,
    user_id bigint NOT NULL,
    event_id bigint NOT NULL,
    organization_id bigint NOT NULL,
    type character varying(255) DEFAULT 'volunteer'::character varying NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    hours_completed numeric(5,2) NOT NULL,
    event_date date NOT NULL,
    issued_date date NOT NULL,
    template character varying(255),
    custom_fields json,
    file_path character varying(255),
    verification_code character varying(255) NOT NULL,
    is_verified boolean DEFAULT true NOT NULL,
    verified_at timestamp(0) without time zone,
    verified_by bigint,
    is_public boolean DEFAULT true NOT NULL,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.certificates OWNER TO swaeduae_user;

--
-- Name: certificates_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.certificates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.certificates_id_seq OWNER TO swaeduae_user;

--
-- Name: certificates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.certificates_id_seq OWNED BY public.certificates.id;


--
-- Name: emergency_communications; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.emergency_communications (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    organization_id bigint NOT NULL,
    created_by bigint NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    priority character varying(255) DEFAULT 'normal'::character varying NOT NULL,
    send_sms boolean DEFAULT false NOT NULL,
    send_email boolean DEFAULT false NOT NULL,
    send_push boolean DEFAULT false NOT NULL,
    recipient_filters json,
    sent_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.emergency_communications OWNER TO swaeduae_user;

--
-- Name: emergency_communications_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.emergency_communications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.emergency_communications_id_seq OWNER TO swaeduae_user;

--
-- Name: emergency_communications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.emergency_communications_id_seq OWNED BY public.emergency_communications.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.events (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text NOT NULL,
    requirements text,
    organization_id bigint NOT NULL,
    category character varying(255) NOT NULL,
    tags json,
    start_date timestamp(0) without time zone NOT NULL,
    end_date timestamp(0) without time zone NOT NULL,
    start_time time(0) without time zone NOT NULL,
    end_time time(0) without time zone NOT NULL,
    location character varying(255) NOT NULL,
    address text NOT NULL,
    city character varying(255) NOT NULL,
    emirate character varying(255) NOT NULL,
    latitude numeric(10,8),
    longitude numeric(11,8),
    max_volunteers integer NOT NULL,
    min_age integer DEFAULT 16 NOT NULL,
    max_age integer,
    skills_required json,
    volunteer_hours numeric(5,2) NOT NULL,
    image character varying(255),
    gallery json,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    rejection_reason text,
    approved_at timestamp(0) without time zone,
    approved_by bigint,
    is_featured boolean DEFAULT false NOT NULL,
    requires_application boolean DEFAULT true NOT NULL,
    application_deadline timestamp(0) without time zone,
    contact_person text,
    contact_email character varying(255),
    contact_phone character varying(255),
    custom_fields json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT events_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'pending'::character varying, 'approved'::character varying, 'published'::character varying, 'cancelled'::character varying, 'completed'::character varying])::text[])))
);


ALTER TABLE public.events OWNER TO swaeduae_user;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_id_seq OWNER TO swaeduae_user;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO swaeduae_user;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO swaeduae_user;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO swaeduae_user;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO swaeduae_user;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobs_id_seq OWNER TO swaeduae_user;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    sender_id bigint NOT NULL,
    recipient_id bigint NOT NULL,
    event_id bigint,
    organization_id bigint,
    content text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.messages OWNER TO swaeduae_user;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO swaeduae_user;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO swaeduae_user;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO swaeduae_user;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_permissions OWNER TO swaeduae_user;

--
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_roles OWNER TO swaeduae_user;

--
-- Name: organization_users; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.organization_users (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role character varying(255) DEFAULT 'member'::character varying NOT NULL,
    joined_at timestamp(0) without time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.organization_users OWNER TO swaeduae_user;

--
-- Name: organization_users_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.organization_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organization_users_id_seq OWNER TO swaeduae_user;

--
-- Name: organization_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.organization_users_id_seq OWNED BY public.organization_users.id;


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.organizations (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(255),
    website character varying(255),
    address text NOT NULL,
    city character varying(255) NOT NULL,
    emirate character varying(255) NOT NULL,
    postal_code character varying(255),
    logo character varying(255),
    documents json,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    rejection_reason text,
    approved_at timestamp(0) without time zone,
    approved_by bigint,
    is_verified boolean DEFAULT false NOT NULL,
    social_media json,
    mission_statement text,
    founded_year integer,
    organization_type character varying(255) DEFAULT 'ngo'::character varying NOT NULL,
    focus_areas json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT organizations_organization_type_check CHECK (((organization_type)::text = ANY ((ARRAY['ngo'::character varying, 'charity'::character varying, 'government'::character varying, 'educational'::character varying, 'corporate'::character varying, 'community'::character varying])::text[]))),
    CONSTRAINT organizations_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying, 'suspended'::character varying])::text[])))
);


ALTER TABLE public.organizations OWNER TO swaeduae_user;

--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.organizations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizations_id_seq OWNER TO swaeduae_user;

--
-- Name: organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.organizations_id_seq OWNED BY public.organizations.id;


--
-- Name: pages; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.pages (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    content text,
    meta_title character varying(255),
    meta_description text,
    meta_keywords character varying(255),
    is_published boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    template character varying(255),
    options json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.pages OWNER TO swaeduae_user;

--
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pages_id_seq OWNER TO swaeduae_user;

--
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.pages_id_seq OWNED BY public.pages.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO swaeduae_user;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.permissions OWNER TO swaeduae_user;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO swaeduae_user;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name text NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO swaeduae_user;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO swaeduae_user;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.role_has_permissions OWNER TO swaeduae_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO swaeduae_user;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO swaeduae_user;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: scheduled_reports; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.scheduled_reports (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    format character varying(255) NOT NULL,
    frequency character varying(255) NOT NULL,
    "time" time(0) without time zone NOT NULL,
    recipients json NOT NULL,
    parameters json,
    is_active boolean DEFAULT true NOT NULL,
    last_run_at timestamp(0) without time zone,
    next_run_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.scheduled_reports OWNER TO swaeduae_user;

--
-- Name: scheduled_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.scheduled_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduled_reports_id_seq OWNER TO swaeduae_user;

--
-- Name: scheduled_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.scheduled_reports_id_seq OWNED BY public.scheduled_reports.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO swaeduae_user;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    key character varying(255) NOT NULL,
    value text,
    type character varying(255) DEFAULT 'string'::character varying NOT NULL,
    "group" character varying(255) DEFAULT 'general'::character varying NOT NULL,
    description text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.settings OWNER TO swaeduae_user;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.settings_id_seq OWNER TO swaeduae_user;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: user_badges; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.user_badges (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    badge_id bigint NOT NULL,
    earned_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.user_badges OWNER TO swaeduae_user;

--
-- Name: user_badges_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.user_badges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_badges_id_seq OWNER TO swaeduae_user;

--
-- Name: user_badges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.user_badges_id_seq OWNED BY public.user_badges.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: swaeduae_user
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    phone character varying(255),
    date_of_birth date,
    gender character varying(255),
    nationality character varying(255),
    emirates_id character varying(255),
    address text,
    city character varying(255),
    emirate character varying(255),
    postal_code character varying(255),
    emergency_contact_name character varying(255),
    emergency_contact_phone character varying(255),
    emergency_contact_relationship character varying(255),
    skills json,
    interests json,
    bio text,
    avatar character varying(255),
    languages json,
    education_level character varying(255),
    occupation character varying(255),
    has_transportation boolean DEFAULT false NOT NULL,
    availability json,
    total_volunteer_hours numeric(8,2) DEFAULT '0'::numeric NOT NULL,
    total_events_attended integer DEFAULT 0 NOT NULL,
    points integer DEFAULT 0 NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    verified_at timestamp(0) without time zone,
    profile_completed boolean DEFAULT false NOT NULL,
    notification_preferences json,
    privacy_settings json,
    last_active_at timestamp(0) without time zone,
    unique_id character varying(255) NOT NULL,
    CONSTRAINT users_gender_check CHECK (((gender)::text = ANY ((ARRAY['male'::character varying, 'female'::character varying, 'other'::character varying, 'prefer_not_to_say'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO swaeduae_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: swaeduae_user
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO swaeduae_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swaeduae_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: applications id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.applications ALTER COLUMN id SET DEFAULT nextval('public.applications_id_seq'::regclass);


--
-- Name: attendances id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.attendances ALTER COLUMN id SET DEFAULT nextval('public.attendances_id_seq'::regclass);


--
-- Name: badge_progress id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.badge_progress ALTER COLUMN id SET DEFAULT nextval('public.badge_progress_id_seq'::regclass);


--
-- Name: badges id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.badges ALTER COLUMN id SET DEFAULT nextval('public.badges_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: certificates id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.certificates ALTER COLUMN id SET DEFAULT nextval('public.certificates_id_seq'::regclass);


--
-- Name: emergency_communications id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.emergency_communications ALTER COLUMN id SET DEFAULT nextval('public.emergency_communications_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: organization_users id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.organization_users ALTER COLUMN id SET DEFAULT nextval('public.organization_users_id_seq'::regclass);


--
-- Name: organizations id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.organizations ALTER COLUMN id SET DEFAULT nextval('public.organizations_id_seq'::regclass);


--
-- Name: pages id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.pages ALTER COLUMN id SET DEFAULT nextval('public.pages_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: scheduled_reports id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.scheduled_reports ALTER COLUMN id SET DEFAULT nextval('public.scheduled_reports_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: user_badges id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.user_badges ALTER COLUMN id SET DEFAULT nextval('public.user_badges_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.announcements (id, event_id, organization_id, created_by, title, content, type, is_published, published_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: applications; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.applications (id, user_id, event_id, status, motivation, skills, availability, experience, custom_responses, documents, rejection_reason, applied_at, reviewed_at, reviewed_by, attended, checked_in_at, checked_out_at, hours_completed, rating, feedback, volunteer_feedback, volunteer_rating, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: attendances; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.attendances (id, user_id, event_id, application_id, checked_in_at, checkin_latitude, checkin_longitude, checkin_qr_code, checkin_device_info, checkin_notes, checked_out_at, checkout_latitude, checkout_longitude, checkout_qr_code, checkout_device_info, checkout_notes, is_valid_checkin, is_valid_checkout, distance_from_event, total_hours, actual_hours, status, verified_by_organizer, verified_by, verified_at, verification_notes, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: badge_progress; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.badge_progress (id, user_id, badge_id, progress, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: badges; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.badges (id, name, slug, description, icon, color, type, criteria, points, is_active, sort_order, created_at, updated_at) FROM stdin;
1	First Timer	first-event	Completed your first volunteer event	first-timer-icon.png	#FF0000	events	{"events_attended":1}	50	t	1	2025-10-30 14:55:27	2025-10-30 14:55:27
2	Five Events	five-events	Participated in five volunteer events	five-events-icon.png	#00FF00	events	{"events_attended":5}	100	t	2	2025-10-30 14:55:27	2025-10-30 14:55:27
3	Ten Hours	ten-hours	Volunteered for ten hours	ten-hours-icon.png	#0000FF	hours	{"volunteer_hours":10}	75	t	3	2025-10-30 14:55:27	2025-10-30 14:55:27
4	Fifty Hours	fifty-hours	Volunteered for fifty hours	fifty-hours-icon.png	#FFFF00	hours	{"volunteer_hours":50}	200	t	4	2025-10-30 14:55:27	2025-10-30 14:55:27
5	First Certificate	first-certificate	Earned your first certificate	first-certificate-icon.png	#FF00FF	achievement	{"certificates_earned":1}	60	t	5	2025-10-30 14:55:27	2025-10-30 14:55:27
6	Community Champion	community-champion	Outstanding community contribution	champion-icon.png	#00FFFF	special	{"volunteer_hours":100,"events_attended":20}	500	t	6	2025-10-30 14:55:27	2025-10-30 14:55:27
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.cache (key, value, expiration) FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.categories (id, name, description, icon, color, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.certificates (id, certificate_number, user_id, event_id, organization_id, type, title, description, hours_completed, event_date, issued_date, template, custom_fields, file_path, verification_code, is_verified, verified_at, verified_by, is_public, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: emergency_communications; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.emergency_communications (id, event_id, organization_id, created_by, title, content, priority, send_sms, send_email, send_push, recipient_filters, sent_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.events (id, title, slug, description, requirements, organization_id, category, tags, start_date, end_date, start_time, end_time, location, address, city, emirate, latitude, longitude, max_volunteers, min_age, max_age, skills_required, volunteer_hours, image, gallery, status, rejection_reason, approved_at, approved_by, is_featured, requires_application, application_deadline, contact_person, contact_email, contact_phone, custom_fields, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.messages (id, sender_id, recipient_id, event_id, organization_id, content, is_read, read_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.migrations (id, migration, batch) FROM stdin;
24	0001_01_01_000000_create_users_table	1
25	0001_01_01_000001_create_cache_table	1
26	0001_01_01_000002_create_jobs_table	1
27	2025_10_29_080239_create_permission_tables	1
28	2025_10_29_080259_create_personal_access_tokens_table	1
29	2025_10_29_082017_create_organizations_table	1
30	2025_10_29_082024_create_events_table	1
31	2025_10_29_082031_create_applications_table	1
32	2025_10_29_082038_create_certificates_table	1
33	2025_10_29_082045_create_badges_table	1
34	2025_10_29_082340_create_user_badges_table	1
35	2025_10_29_082405_add_volunteer_fields_to_users_table	1
36	2025_10_29_104554_create_attendances_table	1
37	2025_10_29_210017_create_organization_users_table	1
38	2025_10_29_210825_create_categories_table	1
39	2025_10_30_080615_create_announcements_table	1
40	2025_10_30_080626_create_messages_table	1
41	2025_10_30_081643_create_emergency_communications_table	1
42	2025_10_30_100000_create_badge_progress_table	1
43	2025_10_30_150000_create_scheduled_reports_table	1
44	2025_10_30_153000_add_unique_id_to_users_table	1
45	2025_10_30_160000_create_settings_table	1
46	2025_10_30_163000_create_pages_table	1
\.


--
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.model_has_permissions (permission_id, model_type, model_id) FROM stdin;
\.


--
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.model_has_roles (role_id, model_type, model_id) FROM stdin;
2	App\\Models\\User	2
5	App\\Models\\User	3
3	App\\Models\\User	4
5	App\\Models\\User	5
5	App\\Models\\User	6
\.


--
-- Data for Name: organization_users; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.organization_users (id, organization_id, user_id, role, joined_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.organizations (id, name, slug, description, email, phone, website, address, city, emirate, postal_code, logo, documents, status, rejection_reason, approved_at, approved_by, is_verified, social_media, mission_statement, founded_year, organization_type, focus_areas, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.pages (id, title, slug, content, meta_title, meta_description, meta_keywords, is_published, sort_order, template, options, created_at, updated_at) FROM stdin;
3	Cookie Policy	cookie-policy	<h2>Cookie Policy</h2>\n                <p>Last updated: October 30, 2025</p>\n                \n                <h3>What Are Cookies?</h3>\n                <p>Cookies are small pieces of text sent to your web browser by a website you visit. They help that website remember information about your visit.</p>\n                \n                <h3>How We Use Cookies</h3>\n                <p>We use cookies to:</p>\n                <ul>\n                    <li>Keep you signed in</li>\n                    <li>Understand how you use our website</li>\n                    <li>Remember your preferences</li>\n                    <li>Improve your experience</li>\n                </ul>\n                \n                <h3>Types of Cookies We Use</h3>\n                <ul>\n                    <li><strong>Essential Cookies:</strong> Required for the website to function properly</li>\n                    <li><strong>Functional Cookies:</strong> Remember your preferences and choices</li>\n                    <li><strong>Analytics Cookies:</strong> Help us understand how visitors use our website</li>\n                </ul>\n                \n                <h3>Managing Cookies</h3>\n                <p>You can control and/or delete cookies as you wish. You can delete all cookies that are already on your computer and you can set most browsers to prevent them from being placed.</p>\n                \n                <h3>Contact Us</h3>\n                <p>For questions about our use of cookies, contact privacy@swaeduae.ae</p>	Cookie Policy - SwaedUAE	Learn about how SwaedUAE uses cookies to improve your experience.	\N	t	3	\N	\N	2025-10-30 13:24:18	2025-10-30 13:24:18
4	FAQ - Frequently Asked Questions	faq	<h2>Frequently Asked Questions</h2>\n                \n                <h3>General Questions</h3>\n                \n                <h4>What is SwaedUAE?</h4>\n                <p>SwaedUAE is a volunteer management platform that connects volunteers with organizations across the UAE, making it easy to find, join, and track volunteer opportunities.</p>\n                \n                <h4>Is SwaedUAE free to use?</h4>\n                <p>Yes! SwaedUAE is completely free for both volunteers and organizations.</p>\n                \n                <h3>For Volunteers</h3>\n                \n                <h4>How do I sign up as a volunteer?</h4>\n                <p>Click the "Volunteer Sign Up" button on the homepage and fill in your details. Once registered, you can browse and apply for volunteer opportunities immediately.</p>\n                \n                <h4>How do I find volunteer opportunities?</h4>\n                <p>Browse available opportunities on the Events page or through your dashboard after logging in. You can filter by location, date, and interest area.</p>\n                \n                <h4>Can I earn certificates?</h4>\n                <p>Yes! After completing volunteer activities, organizations can issue certificates that you can download and share.</p>\n                \n                <h3>For Organizations</h3>\n                \n                <h4>How can my organization join?</h4>\n                <p>Click "Organization Sign Up" and submit your organization details. Our team will review and approve your registration.</p>\n                \n                <h4>How do I post volunteer opportunities?</h4>\n                <p>Once your organization is approved, you can create and manage volunteer events through your organization dashboard.</p>\n                \n                <h4>How do I track volunteer attendance?</h4>\n                <p>Our platform provides QR code-based check-in/check-out system and real-time attendance tracking for all your events.</p>\n                \n                <h3>Need More Help?</h3>\n                <p>If you couldn't find the answer to your question, please contact us at support@swaeduae.ae</p>	FAQ - Frequently Asked Questions | SwaedUAE	Find answers to common questions about volunteering and using the SwaedUAE platform.	\N	t	4	\N	\N	2025-10-30 13:24:18	2025-10-30 13:24:18
5	Volunteer Guide	volunteer-guide	<h2>Volunteer Guide</h2>\n                <p>Welcome to the SwaedUAE Volunteer Guide! This guide will help you make the most of your volunteering experience.</p>\n                \n                <h3>Getting Started</h3>\n                <ol>\n                    <li><strong>Create Your Profile:</strong> Sign up and complete your volunteer profile with your skills, interests, and availability.</li>\n                    <li><strong>Browse Opportunities:</strong> Explore available volunteer opportunities that match your interests.</li>\n                    <li><strong>Apply:</strong> Submit applications for events you're interested in.</li>\n                    <li><strong>Get Confirmed:</strong> Wait for organization approval.</li>\n                    <li><strong>Participate:</strong> Attend the event and make a difference!</li>\n                </ol>\n                \n                <h3>Best Practices</h3>\n                <ul>\n                    <li>Complete your profile thoroughly to help organizations find you</li>\n                    <li>Only apply for events you can commit to attending</li>\n                    <li>Arrive on time and be prepared</li>\n                    <li>Follow organization guidelines and instructions</li>\n                    <li>Communicate any issues or conflicts promptly</li>\n                </ul>\n                \n                <h3>Earning Badges and Certificates</h3>\n                <p>As you volunteer, you'll earn badges for milestones like hours completed, events attended, and special achievements. Organizations will also issue certificates for your contributions.</p>\n                \n                <h3>Tracking Your Impact</h3>\n                <p>Use your dashboard to:</p>\n                <ul>\n                    <li>View your volunteer hours</li>\n                    <li>See badges you've earned</li>\n                    <li>Download certificates</li>\n                    <li>Track your applications</li>\n                </ul>\n                \n                <h3>Need Help?</h3>\n                <p>Contact us at volunteer@swaeduae.ae for assistance.</p>	Volunteer Guide - How to Get Started | SwaedUAE	Learn how to become an effective volunteer and make the most of the SwaedUAE platform.	\N	t	5	\N	\N	2025-10-30 13:24:18	2025-10-30 13:24:18
2	Terms of Service	terms-of-service	<p>Acceptance of Terms\n                </p>\n\n<p>By accessing or using the SwaedUAE platform, you agree to be bound by these Terms of Service and all applicable laws and regulations.</p><p>\n                \n                Use of Service\n                </p>\n\n<p>You agree to use our services only for lawful purposes and in accordance with these Terms of Service. You must not:</p>\n                <ul>\n                    <li>Violate any applicable laws or regulations</li>\n                    <li>Infringe upon the rights of others</li>\n                    <li>Transmit any harmful or malicious content</li>\n                    <li>Attempt to gain unauthorized access to our systems</li>\n                </ul><p>\n                \n                User Accounts\n                </p>\n\n<p>When you create an account, you are responsible for maintaining the confidentiality of your account and password. You agree to accept responsibility for all activities that occur under your account.</p><p>\n                \n                Volunteer Responsibilities\n                </p>\n\n<p>As a volunteer, you agree to:</p>\n                <ul>\n                    <li>Provide accurate and complete information</li>\n                    <li>Follow the instructions of event organizers</li>\n                    <li>Respect the rights and dignity of all participants</li>\n                    <li>Comply with all applicable laws and regulations</li>\n                </ul><p>\n                \n                Organization Responsibilities\n                </p>\n\n<p>Organizations using our platform agree to:</p>\n                <ul>\n                    <li>Provide accurate information about volunteer opportunities</li>\n                    <li>Treat all volunteers with respect and fairness</li>\n                    <li>Ensure the safety and well-being of volunteers</li>\n                    <li>Comply with all applicable laws and regulations</li>\n                </ul><p>\n                \n                Limitation of Liability\n                </p>\n\n<p>SwaedUAE shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of our services.</p><p>\n                \n                Changes to Terms\n                </p>\n\n<p>We reserve the right to modify these terms at any time. We will notify you of any changes by posting the new Terms of Service on this page.</p>	Terms of Service - SwaedUAE Volunteer Platform	Read our terms of service to understand your rights and responsibilities when using the SwaedUAE volunteer management platform in the UAE.	terms of service, volunteer, uae, swaeduae, agreement	t	4	\N	\N	2025-10-30 13:24:18	2025-10-30 14:55:27
6	Organization Resources	organization-resources	<h2>Organization Resources</h2>\n                <p>Everything you need to successfully manage volunteers through SwaedUAE.</p>\n                \n                <h3>Getting Started</h3>\n                <ol>\n                    <li><strong>Register:</strong> Submit your organization details for approval</li>\n                    <li><strong>Complete Profile:</strong> Add your organization information, logo, and description</li>\n                    <li><strong>Create Events:</strong> Post volunteer opportunities</li>\n                    <li><strong>Manage Applications:</strong> Review and approve volunteer applications</li>\n                    <li><strong>Track Attendance:</strong> Use our QR code system for check-in/check-out</li>\n                </ol>\n                \n                <h3>Features Available</h3>\n                <ul>\n                    <li><strong>Event Management:</strong> Create and manage volunteer opportunities</li>\n                    <li><strong>Attendance Tracking:</strong> Real-time attendance monitoring with QR codes</li>\n                    <li><strong>Certificate Generation:</strong> Issue certificates to volunteers</li>\n                    <li><strong>Communication Tools:</strong> Send announcements and messages to volunteers</li>\n                    <li><strong>Reporting:</strong> Access analytics and volunteer statistics</li>\n                </ul>\n                \n                <h3>Best Practices</h3>\n                <ul>\n                    <li>Provide clear event descriptions and requirements</li>\n                    <li>Respond to volunteer applications promptly</li>\n                    <li>Communicate schedule changes immediately</li>\n                    <li>Recognize and appreciate your volunteers</li>\n                    <li>Issue certificates for completed activities</li>\n                </ul>\n                \n                <h3>Support</h3>\n                <p>For organization support, email organizations@swaeduae.ae or call +971 4 123 4567</p>	Organization Resources - Manage Volunteers | SwaedUAE	Resources and guides for organizations to effectively manage volunteers on SwaedUAE.	\N	t	6	\N	\N	2025-10-30 13:24:18	2025-10-30 13:24:18
10	About Us	about-us	<p>Welcome to SwaedUAE, the premier volunteer management platform in the United Arab Emirates. Our mission is to connect passionate volunteers with meaningful opportunities that make a positive impact in our communities.</p><p>\n                \n                Our Vision\n                </p>\n\n<p>We envision a UAE where every individual has the opportunity to contribute to society through meaningful volunteer work, creating stronger, more connected communities across all emirates.</p><p>\n                \n                Our Mission\n                </p>\n\n<p>Our mission is to empower volunteers and organizations by providing a comprehensive platform that facilitates meaningful connections, tracks impact, and celebrates contributions to society.</p><p>\n                \n                Core Values\n                </p>\n\n<ul>\n                    <li><strong>Community:</strong> Building stronger connections between people and organizations</li>\n                    <li><strong>Integrity:</strong> Maintaining transparency and honesty in all our operations</li>\n                    <li><strong>Inclusivity:</strong> Welcoming volunteers from all backgrounds and abilities</li>\n                    <li><strong>Impact:</strong> Measuring and celebrating the positive change we create</li>\n                    <li><strong>Innovation:</strong> Continuously improving our platform and services</li>\n                </ul>	About SwaedUAE - Volunteer Management Platform UAE	Learn about SwaedUAE, the leading volunteer management platform in the UAE that connects volunteers with meaningful opportunities across all emirates.	volunteer, uae, community service, volunteer management, swaeduae	t	1	\N	\N	2025-10-30 14:55:27	2025-10-30 14:55:27
11	Contact Us	contact-us	<p>Get In Touch\n                </p>\n\n<p>We'd love to hear from you! Whether you have questions about volunteering, need help with your account, or want to partner with us as an organization, our team is here to assist you.</p>\n                \n                <div>\n                    <div>\n                        <div>\n                            \n                        </div>\n                        Email Us\n                        <p>support@swaeduae.ae</p>\n                        <p>partnerships@swaeduae.ae</p>\n                    </div>\n                    \n                    <div>\n                        <div>\n                            \n                        </div>\n                        Call Us\n                        <p>+971 4 123 4567</p>\n                        <p>Mon-Fri, 9AM-5PM</p>\n                    </div>\n                    \n                    <div>\n                        <div>\n                            \n                        </div>\n                        Visit Us\n                        <p>Dubai, UAE</p>\n                        <p>Office 123, Business Bay</p>\n                    </div>\n                </div><p>\n                \n                Frequently Asked Questions\n                </p>\n\n<p>Before contacting us, you might find answers to your questions in our <a href="#">FAQ section</a>.</p>	Contact SwaedUAE - Volunteer Management Platform UAE	Contact SwaedUAE for support with volunteering, organization partnerships, or general inquiries about our volunteer management platform in the UAE.	contact, volunteer, uae, support, swaeduae	t	2	\N	\N	2025-10-30 14:55:27	2025-10-30 14:55:27
1	Privacy Policy	privacy-policy	<p>Introduction\n                </p>\n\n<p>SwaedUAE ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website and use our services.</p><p>\n                \n                Information We Collect\n                </p>\n\n<p>We collect information that you provide directly to us, including:</p>\n                <ul>\n                    <li>Personal identification information (name, email address, phone number)</li>\n                    <li>Demographic information (age, gender, nationality)</li>\n                    <li>Professional information (skills, interests, availability)</li>\n                    <li>Emergency contact information</li>\n                    <li>Payment information (if applicable)</li>\n                </ul><p>\n                \n                How We Use Your Information\n                </p>\n\n<p>We use the information we collect to:</p>\n                <ul>\n                    <li>Provide, maintain, and improve our services</li>\n                    <li>Process volunteer applications and event registrations</li>\n                    <li>Communicate with you about events and opportunities</li>\n                    <li>Send you administrative information</li>\n                    <li>Protect the security and integrity of our platform</li>\n                </ul><p>\n                \n                Information Sharing\n                </p>\n\n<p>We may share your information with:</p>\n                <ul>\n                    <li>Organizations you volunteer with</li>\n                    <li>Service providers who assist us in operating our platform</li>\n                    <li>Legal authorities when required by law</li>\n                </ul><p>\n                \n                Your Rights\n                </p>\n\n<p>You have the right to:</p>\n                <ul>\n                    <li>Access and update your personal information</li>\n                    <li>Delete your account and personal data</li>\n                    <li>Object to the processing of your personal data</li>\n                    <li>Request data portability</li>\n                </ul><p>\n                \n                Contact Us\n                </p>\n\n<p>If you have any questions about this Privacy Policy, please contact us at privacy@swaeduae.ae.</p>	Privacy Policy - SwaedUAE Volunteer Platform	Read our privacy policy to understand how SwaedUAE collects, uses, and protects your personal information when using our volunteer management platform.	privacy policy, data protection, volunteer, uae, swaeduae	t	3	\N	\N	2025-10-30 13:24:18	2025-10-30 14:55:27
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
alsadi22@gmail.com	$2y$12$644zvLZ4TZyzGUIRDO4lgeaSVa45cv8Cu78TfF6cRRCb0FiaVUGEK	2025-10-30 15:09:11
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM stdin;
1	view users	web	2025-10-30 14:55:13	2025-10-30 14:55:13
2	create users	web	2025-10-30 14:55:13	2025-10-30 14:55:13
3	edit users	web	2025-10-30 14:55:13	2025-10-30 14:55:13
4	delete users	web	2025-10-30 14:55:13	2025-10-30 14:55:13
5	verify users	web	2025-10-30 14:55:13	2025-10-30 14:55:13
6	view organizations	web	2025-10-30 14:55:13	2025-10-30 14:55:13
7	create organizations	web	2025-10-30 14:55:13	2025-10-30 14:55:13
8	edit organizations	web	2025-10-30 14:55:13	2025-10-30 14:55:13
9	delete organizations	web	2025-10-30 14:55:14	2025-10-30 14:55:14
10	approve organizations	web	2025-10-30 14:55:14	2025-10-30 14:55:14
11	reject organizations	web	2025-10-30 14:55:14	2025-10-30 14:55:14
12	manage own organization	web	2025-10-30 14:55:14	2025-10-30 14:55:14
13	view events	web	2025-10-30 14:55:14	2025-10-30 14:55:14
14	create events	web	2025-10-30 14:55:14	2025-10-30 14:55:14
15	edit events	web	2025-10-30 14:55:14	2025-10-30 14:55:14
16	delete events	web	2025-10-30 14:55:14	2025-10-30 14:55:14
17	approve events	web	2025-10-30 14:55:14	2025-10-30 14:55:14
18	reject events	web	2025-10-30 14:55:14	2025-10-30 14:55:14
19	manage own events	web	2025-10-30 14:55:14	2025-10-30 14:55:14
20	feature events	web	2025-10-30 14:55:14	2025-10-30 14:55:14
21	view applications	web	2025-10-30 14:55:14	2025-10-30 14:55:14
22	create applications	web	2025-10-30 14:55:14	2025-10-30 14:55:14
23	edit applications	web	2025-10-30 14:55:14	2025-10-30 14:55:14
24	delete applications	web	2025-10-30 14:55:14	2025-10-30 14:55:14
25	approve applications	web	2025-10-30 14:55:14	2025-10-30 14:55:14
26	reject applications	web	2025-10-30 14:55:14	2025-10-30 14:55:14
27	manage own applications	web	2025-10-30 14:55:14	2025-10-30 14:55:14
28	check in volunteers	web	2025-10-30 14:55:14	2025-10-30 14:55:14
29	check out volunteers	web	2025-10-30 14:55:14	2025-10-30 14:55:14
30	view certificates	web	2025-10-30 14:55:14	2025-10-30 14:55:14
31	create certificates	web	2025-10-30 14:55:14	2025-10-30 14:55:14
32	edit certificates	web	2025-10-30 14:55:14	2025-10-30 14:55:14
33	delete certificates	web	2025-10-30 14:55:14	2025-10-30 14:55:14
34	verify certificates	web	2025-10-30 14:55:14	2025-10-30 14:55:14
35	issue certificates	web	2025-10-30 14:55:14	2025-10-30 14:55:14
36	view badges	web	2025-10-30 14:55:14	2025-10-30 14:55:14
37	create badges	web	2025-10-30 14:55:14	2025-10-30 14:55:14
38	edit badges	web	2025-10-30 14:55:14	2025-10-30 14:55:14
39	delete badges	web	2025-10-30 14:55:14	2025-10-30 14:55:14
40	award badges	web	2025-10-30 14:55:14	2025-10-30 14:55:14
41	view reports	web	2025-10-30 14:55:14	2025-10-30 14:55:14
42	export data	web	2025-10-30 14:55:14	2025-10-30 14:55:14
43	view analytics	web	2025-10-30 14:55:14	2025-10-30 14:55:14
44	manage system settings	web	2025-10-30 14:55:14	2025-10-30 14:55:14
45	manage roles	web	2025-10-30 14:55:14	2025-10-30 14:55:14
46	manage permissions	web	2025-10-30 14:55:14	2025-10-30 14:55:14
47	view logs	web	2025-10-30 14:55:14	2025-10-30 14:55:14
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.role_has_permissions (permission_id, role_id) FROM stdin;
1	1
2	1
3	1
4	1
5	1
6	1
7	1
8	1
9	1
10	1
11	1
12	1
13	1
14	1
15	1
16	1
17	1
18	1
19	1
20	1
21	1
22	1
23	1
24	1
25	1
26	1
27	1
28	1
29	1
30	1
31	1
32	1
33	1
34	1
35	1
36	1
37	1
38	1
39	1
40	1
41	1
42	1
43	1
44	1
45	1
46	1
47	1
1	2
2	2
3	2
5	2
6	2
10	2
11	2
13	2
17	2
18	2
20	2
21	2
25	2
26	2
30	2
34	2
35	2
36	2
37	2
38	2
40	2
41	2
42	2
43	2
12	3
13	3
14	3
15	3
19	3
21	3
25	3
26	3
27	3
28	3
29	3
30	3
31	3
35	3
41	3
43	3
13	4
19	4
21	4
27	4
28	4
29	4
30	4
13	5
22	5
30	5
36	5
1	6
5	6
6	6
10	6
11	6
13	6
17	6
18	6
21	6
30	6
34	6
41	6
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.roles (id, name, guard_name, created_at, updated_at) FROM stdin;
1	super-admin	web	2025-10-30 14:55:14	2025-10-30 14:55:14
2	admin	web	2025-10-30 14:55:14	2025-10-30 14:55:14
3	organization-manager	web	2025-10-30 14:55:14	2025-10-30 14:55:14
4	organization-staff	web	2025-10-30 14:55:14	2025-10-30 14:55:14
5	volunteer	web	2025-10-30 14:55:14	2025-10-30 14:55:14
6	moderator	web	2025-10-30 14:55:14	2025-10-30 14:55:14
\.


--
-- Data for Name: scheduled_reports; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.scheduled_reports (id, name, type, format, frequency, "time", recipients, parameters, is_active, last_run_at, next_run_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
1zJIXUx8a6roPoynY9H6w1um0BEi52F6lsUDVKNB	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoic093MGxKU0k3V3BMMWRUWWJ1anNiU3dLamplRWo0SE5aeE9OTFBaRyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761830474
yCk5ctwYEovF9HYIQ3MC3UxoFHLhSunCrJFIQr5E	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiU2tYNkI0MnlPUDI4V0czcFlqZEFrbk1JeTZZamVIaUpFTkpkdGtrVSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761830474
ZA66bs15wK83Fvs1Qkhu81DvXi1sjW4ypReGfW4M	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoidVBkSU83NWx4bWRvS3dnYWJCUnZYSGpodmx4VjB1bEN2TFNCcFd6eiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761830776
6dplAtUlhXqOKWor95Wgg9ljWzAIh9Ayc8P6ufFB	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVXFiVTdmTHNCUlJ4TTNIV1FSNkVQNDY1ZDhPTGpDMWp4amNUcWtLViI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761830776
eLC6P06kDFPhkaPS5wrJ8KCor94Iz1uVU0C7fCyA	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTHVNWWQwdkpDN2p6WnBZUUo0REhCT3hseXRMYzhTZDZWeEtOSTZVQSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761831077
Xx1wvrhhVBZecQSKBNOt50Q4zROlaWjrsENNnWp3	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZnNXQ2JZMVloRW1BWXc4ejQ5YnlWY21MNUtvZEFueW9MakpMQ3dJRyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761831077
d71g2Ab9HmJUYWTBx6IodE2GKGdBnn2nrqYVbeM5	\N	127.0.0.1	facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiemRDMHYwY2VYMkpFZXFiZUN1QUpwZG1iYjE4UzFaWFVGU3c0MHd5aiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761831212
goVE2mvhISio7u2UGbiOxoNZmtzOs1qpT95SPZDj	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMDl2dUlNcnRaZVhSU0JIMFZ6RGh6UDBGcnVTZUNITWxsMkVRa0lkcCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NjoibG9jYWxlIjtzOjI6ImFyIjt9	1761837371
LvLPTQE367tpXkLK0yoGP0I6Bz8gjfWilZFfnj04	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiS0Nnc0VoWFBMM28yckNxVUdEOGs3bU0wQ1JScllYOXl5c3N0QzJMRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761837684
MSL5g2vBrLa6qDBJBfKVODEwFG9VIzLTFgRNKO3Q	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWDc4eFNnQ204NXR1T1R0SlI2cHVGZDlvVG51ejRraGZEdnhHRVNkOSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761837985
bT2ZuYoO92bTI2IKVs1ahDizM02cCks7nw7263jS	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibVltSkx0d2RXUDhobGhLYzlleUlaOEZ1ZDF5WWJPMHpGbUFjVmxSSSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761838285
Obpylae323Bm7Qp4C46zT3t7KduHpB5Cpxzgz4Sh	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUGF5Nkc5UnFtajFZend2N0kyMXlPc1FiTGo4MGR1ZHkxSEJCTEhuMSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761838585
GfjmX1Y7Jue8rWUZOlOEJueWeptPIgSUS2Pu7O4o	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiR3BYMkVtcWR6dUJJN21KZjFkckJLcTVnVDI2ZHFmYzM2cW5UYmtSWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761838886
adyFaB99psDWvm7mTgB8glE6rZDYFhUBUA1UY7sA	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZEtud21LWDltaG5JQ25MbUZtR1llUUtpSWZhWUVHdFJSdHZ4SEp5ZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761839186
Y39CORr84LgO3pse0UgfFfkSJDuspniBzxyBJHoC	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibGZtZkk2VXR3aXNnOFFZY0txNFdiZzRuZE9xSVdVRTNXcW53TnEzNyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761831378
bwaJ83MnzuJQ7c7D9ytNmr1RHW5D11lBYrYoCOkj	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibWJiTjlVc290aENlZjdoanNZQjRkbGZUdGtrUXliMUNZSTZjYW03OSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761831378
gSn2lETunyl8phm80FhC1jSLbfPtawDLV8cBX78H	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVjNudWFXV1g5bmxZV05jbkNiUWswOG14Z2JOSHI5OVg5WDljc0pWMyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTc6Imh0dHBzOi8vbG9jYWxob3N0IjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761831567
z9pBz8IUDiM2I5ZZQ2sNyJAAwc3FzUnL8wGsA2ed	\N	127.0.0.1	curl/7.81.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQkJzejY0eHVNRmhaM3VaeVFlTlRNelg3QXJQWGNoSTRVRkxMUFhVSSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyNzoiaHR0cHM6Ly9sb2NhbGhvc3QvcGFnZXMvZmFxIjt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vbG9jYWxob3N0L3BhZ2VzL2ZhcSI7czo1OiJyb3V0ZSI7czoxMDoicGFnZXMuc2hvdyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761831621
CklB2bf2xeR1gAKTmZYz8WG32NkDKh9OaoKfAp5P	\N	127.0.0.1	curl/7.81.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMk1lUmZnMzhjWURKQm1nVFl5a2s1TVg4WldvRDFVUVp3RnlDN0RBdCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyNzoiaHR0cHM6Ly9sb2NhbGhvc3QvcGFnZXMvZmFxIjt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vbG9jYWxob3N0L3BhZ2VzL2ZhcSI7czo1OiJyb3V0ZSI7czoxMDoicGFnZXMuc2hvdyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761831642
jWoK3H80h34MGFWPpa2y174DIgkauvmMxal43dgk	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiV3lKUHZONzRpVm1RNkc2Y1liQjM0TmdFUzdQak9kV0hZMEFjWThGdSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761831679
a5E5qUXSRQkhOEAq3vUFqBpPomDoyGY1l5q5ho5u	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZks3SlpMRG9zR3FqMDJGeGVoc3h5VW1mR2hmZjl5V0VlV05NZzVFSiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761831679
Pp02AS9qNBNJYxKAQQemMvs773bf4RtaKRcm3bKc	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoidzcxdFdGZjNkQ0ZLSzZPQnpSb0xId204TVdvQ1FwaGVLSGtLYm84QSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vbG9jYWxob3N0L3BhZ2VzL2ZhcSI7czo1OiJyb3V0ZSI7czoxMDoicGFnZXMuc2hvdyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761831832
uaueeIM6Z7E7Q69TDgy20SxWNxYVux3G1dBNX9yP	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQmtiQUx6d2g3M1gzYkhoU0F3NzVqZUo5TU5lM1JZdEM4TmZZNzEzWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vbG9jYWxob3N0L3BhZ2VzL2ZhcSI7czo1OiJyb3V0ZSI7czoxMDoicGFnZXMuc2hvdyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761831844
FEQfjm9ZBAfAQWOIeegqNYiGu1c0I3Q74H9p85tV	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVndROFNZWWRvSjR5RXVPTU5QampyeXk4RE91MGE1WlRGcURmdFY4QyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vbG9jYWxob3N0L3BhZ2VzL2ZhcSI7czo1OiJyb3V0ZSI7czoxMDoicGFnZXMuc2hvdyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761831858
3gar7dJy4tH1GGKkCrbXOizf7Q3hnxBYUKIkGZgF	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNXNrajRSendHem5jOUNHS2dTQnBORUZCUkxPY1lwN1ZFNktEVkJkNSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761831980
yYm2gU81qCb59ZjdW58o1urhnQq75g8ICwmNcapI	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUldlOUhCMXN6RU9iWWh5QmJtMFRoMnJZMVIxYUt1UTZ4aGFsU1dyWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761831980
pPrXgLWdc65vT0fH1jl5gHIQtzTTQditZZRN22qC	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoib255NjVFdTR4WmVQRGtVY3hGNEpTNjNpcFJhVXBYQ0Z5aEZaQXlhTSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vbG9jYWxob3N0L3BhZ2VzL2ZhcSI7czo1OiJyb3V0ZSI7czoxMDoicGFnZXMuc2hvdyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761832019
9cuA75uPmIVQogFzxd9wB9Akm3R8gp06jyAkhVfU	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUUZBZ2t3VlpjZ2RJYzE0SXlyeFU4OWIwV2M1U2NlZml0VzJvRHdDayI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vbG9jYWxob3N0L3BhZ2VzL2ZhcSI7czo1OiJyb3V0ZSI7czoxMDoicGFnZXMuc2hvdyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761832032
SBOShFzPXv6jo8HK4QaLgR7me8Uu0E8fwQ1HETus	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTWFHOU9nS2RUZ2gxQ3Npd1I1dlFQQXhlQXZNZWZ5NWN1b2Q1SnVTbSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vbG9jYWxob3N0L3BhZ2VzL2ZhcSI7czo1OiJyb3V0ZSI7czoxMDoicGFnZXMuc2hvdyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761832048
POETAnJVYia2Dk9lkg0kV8jNpsaIp7f7JAKvO6Rt	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNDlSOFBld1QzdjhNc1FmaEtLMkhtUGIyWUEwa2lqSTNVTUJpOTVyMSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vbG9jYWxob3N0L3BhZ2VzL2ZhcSI7czo1OiJyb3V0ZSI7czoxMDoicGFnZXMuc2hvdyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761832133
r7FhJta3x5gOkP3g5PkoblZVzG6HLoJwdRqtVlTk	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiV2NncUk5SzhNS2k3ZHBHRTBFME42amViNVNqQ2gyT2JvVThnZTJtdCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vbG9jYWxob3N0L3BhZ2VzL2ZhcSI7czo1OiJyb3V0ZSI7czoxMDoicGFnZXMuc2hvdyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761832187
lxzgjACQnURyaSEe85IiEi7KVHhwPPfxHa31AmmO	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiemx6aTQxSUVyZ0t6cURzTFFwaWNKeERSaFYySDhLbXFxU054elNBYyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTc6Imh0dHBzOi8vbG9jYWxob3N0IjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761832239
4aY4GYlGJmeBsjPcPPnDF7Hx5xwnU1eAXVed2n8F	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVkIxbldtbU9GRzlucXA5SGlyUkpXakdTS21zYnNvM3lOeW1Eb1RoRyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTc6Imh0dHBzOi8vbG9jYWxob3N0IjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761832258
NisS3NhYuf6L6kNyGLfqwtF2iGS5pXXdSCuRDkg8	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoidHRKbUZPU3Exd2JzbjdKZ2QyNWRMeXE4aFdjUGNOcG1EbE9VcEtVeCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761832280
ExTWbTftXZer6BujKIrkybGof89bL13SbRMhCnxQ	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibTlXNzRRM2pwemxVSndYbVR2SndXTmlFMlBTeGtzR0VHT1d0T2VrMyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761832280
4bzeWLnnaO82XRIw4JdE0ipZO8iA9MhtU0XEePQk	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTTFnbXJweXFPWXlHWmE2azYxV2IwejJGTWdLUGY2TFMyeDNVVnNvdSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTc6Imh0dHBzOi8vbG9jYWxob3N0IjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761832286
MiZibby3f5MNz9pUEWhjAQqCVmrzy3tYvBRbgGft	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUHRzcE41NDBxVDJ2VnQwRG5SVmdJRUpuOHJKbGlPNTlqVVA3MUhaayI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTc6Imh0dHBzOi8vbG9jYWxob3N0IjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761832337
NfD6AjxXe48QBTW63UYNtZeP6yUGSHisSI0fgP8A	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoieEJRM1ZhVm43NWhKbXc0cGl5N0dPMFJCWE9YVVVVak1ZZ1luSWJpTyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTc6Imh0dHBzOi8vbG9jYWxob3N0IjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761832362
Eb5dQf1qknSfX0yoyn0i1oaOel6GBqpYlpILRe7S	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoidGh0bmRhREZ1Vnhnd3JHeWpSY2h1aGU3QzJwd05iVmxPcDBrU3ExbyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTc6Imh0dHBzOi8vbG9jYWxob3N0IjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761832385
HNmgLmyfb6lQ5Ujj3AHxZ3UcyTc1140XCML3EO6X	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVW1BWXh1eEt0WVozZG5aYWV1WHlVQUpoYXRrZ29HRmpTTXVJZktJSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761832580
gaagOuGBGf1jnN0JkFnuZIOXlRIs8a2bxp8NW810	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoieWNzRGR6YnlFSnNWTXFYZGNyMnRyUzNPV3FCT0tOazBRWHhJNFZxaCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761832580
Nzyp3VTUrR1kHUxlAJDTD5cSPq0s0KlQsy4JOHWB	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiY2V2UzdVUGg2YldCbG1LRU1nR2RrSnBqdURnNFIxeWhFY0wwNWpFdSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761832802
ziISASYmXrj488HQBbhTbDHX7snXezLaE2QTlzhB	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRFlDbmtSUjFTRmJjTjUxQUJBbzFnYXFaUUdMSDFCaG9ZN05rd1haTiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761832881
NkVccRFVIt3mUcgOoP6J9xtFWAlSHirLLfRjFRtk	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiajlhc3gySmxiNjMyTlowdkgzUFN6aE5xbE1HM1ZLSDJRY2FmQ0thMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761832881
irL6D8kayTVD5YgnutsUYhLmiP31SEQKLLmoaqMu	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiemo5NGZRR0xPMjlWZW9ua1lHRkpvY1lKMzdIN05rUTVyMU15Mzh1ciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761833181
q9m3fcpJrV2hS2jio5rVsacjNQWQdErVtLeyqWES	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiR3lncHJBWmp0SGVBcVBiZURhc1ZKN3dqZUZLMFd1cU03Y2YzejI2OSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761833182
4XyszOosHNnuhuGSHMVo35CoUw6ySDq63ZCZSOU2	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoicTJLNEl5WFd4ZmZVVWI5bUtaWGxQR1RLZlZ0Q2dyRXNORnVlT2pOQyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761833481
sy7p3igEEdibFxTamDJDq0BcanToURDQQIvi20GO	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiY25PWnF5N0ZrbDJLYzEwZWFacTVXVk5ycXdxYUZHQm9MaHBlSG9ldiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761833481
0WFwIdMqHYgVe0fbeVzoHkIa5wm68JxM3t72wBaw	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaWtCOUx4T1dKNzFXaHZnRTdQUTdtdHgxWDk2ZDVsRGR1MnA0NWhWaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761833781
xWRAYWcpPN9nTTm82E9FSFaOVAc6V6fpquJnBGVw	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoid1N4VXozeGZINnRNRkE3Y1VVZzRWWFNIQTR2UHhRUEZmTTNEOUQxOCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761833781
rDf0HYxFavzy0TrMVJChC4sCjuMfdfjlyVeMALFb	\N	127.0.0.1	python-httpx/0.28.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoicVltV29UUEhxOG1ORVY2dDkzTllFb0x2MjR3ZG1OZ1FwbERFYzZoaCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761833984
z5rOPtX0S4Y4SribJNWeF3d1l1DDd7etu0B0pEw6	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOFE0SDhac2V0MmR2SnZBbFg0OVl2QlExUW5FZGxnVDJqak9OVVhHRiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761834081
CHXL7elqlVGI4U23Eo3GsbNl16ZdiaBTA6xGs4YY	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRkdvMk43SHBJcTZYcFgxNlBwTTk0OVpyMnFwUlB3eDJEeWI2UjhpZyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761834081
m8NPWNqTHVdh2OSWmn4iMB5Gc5YB9kQioRw7GMKu	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOWlIaUx3cGRReWM2ajN6bUliQWZIYzBiUUh4UDdiV2wzdnpYbnNwRyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761834381
Y2Aqsxiz8KhiL2iV0dCTo35weJa9pFfTG9izeACF	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNVdkNExUcWxqcG9KQk8zWDE5VWdyZmRneHduMVU5Rk5mR21wQVlDQiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761834382
hYzJodscvhJp2v90Pjiqh5xbl8r2J45vjK1V3qr6	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVU85VkRqVEdYZHlncWNIWjE0eHA3MmdvQUJMUldtUDUwWEZtdHlwYiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761834681
Jw4QVrZP647IgbXwB3shs386XcfGuXQZ2Teei4kB	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoidWFQQUJ1Z2NPVllmVlpiQnBmZFpkTGVNd2NXMjF4NjBVaTR1S1F5NiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761834682
kYXbid1VyyqmotmBLFeoLNGWwCOQosCIBgcB47fB	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoic3R1TFRwM0JnbDJyRldjckhiTkV2UHcyVHVEZWExOEpLbDFIN2Z0NyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761834981
P4lYlczDO6RYLmIO0XWb1md7Pp2hcNsH48onPPhD	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSktadGNhQ0V5aXpXN0ltVW5pNjFjVU81OXhoMmY2a1NKdFhWUU12TiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761834982
hUOlezdKR43Fr9pFYuz0IcVzDacaMU1SMgSejt2j	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibEdUMElaYVdNaklGbnlnb1Q0NkxlakZqbW5SOUY3UWhJYmtwYjNpNSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761835281
7qbWxILCDRZZmE73QLfsNDaC5jNcCc195KncTgi5	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWnNKM3pvblNCV2NSaFJDSUZyaHZreG5zakRqM2NWWjl1Z2ExRWJzdSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761835282
r31RR0ZPZE2XFmta1G4i11yQWgxbIKSzvt6BJbGI	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.7390.122 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)	YTo0OntzOjY6Il90b2tlbiI7czo0MDoidjNuRW5tRmV3Y0cwNW5QZFFzYlhaVUZJREhDbjVWbDRWTVU5QUtYaiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo4MDoiaHR0cHM6Ly93d3cuc3dhZWR1YWUuYWUvZXZlbnRzP29yZ2FuaXphdGlvbj0yZWE4MWQ2ZC0wZTk0LTRjNDYtYjU0MC1kN2M0NjJlN2RlMDEiO31zOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4MDoiaHR0cHM6Ly93d3cuc3dhZWR1YWUuYWUvZXZlbnRzP29yZ2FuaXphdGlvbj0yZWE4MWQ2ZC0wZTk0LTRjNDYtYjU0MC1kN2M0NjJlN2RlMDEiO3M6NToicm91dGUiO3M6MTI6ImV2ZW50cy5pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761835569
EPo0t3uRp6Pp7KsFNmHiBFbcuD3Ig3QChYcqUiLG	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.7390.122 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiN2F1UnFDODV4TGdPdDlGSk9PVHc1b2ZVN0FwdFZqblZCZTRGTUNVVSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjk6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1761835570
lNNo39N9kFNLJQJxZrN6S1YysCHgVmmlQufB328w	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoianZ3TGswVlpyNUcwWXhQTk5UU0JzN1RhQ2JCejZtUmRucFVDREtaRCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761835581
btsRHXHVnFTz8AORJUJODV3Wa4DZ74Hx7DIes6Lm	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNUlKOUhER2xtYzhPNkVJSlM2VkswVVRIUDZkdW5wckphNmwyQmc1MiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761835582
wNSryHvYLNgt8C58VTMuxEOkiXAACLjVL05ESer9	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoieFB3QU4wejZLS2hVVTd0Y2VtOUt5TjVpT0VsdDR5NWZBWXQ0eW1XUyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761837383
HJQ9NQ7e8lAYpeat1hkYDHTmHSckPd1PaR3Nxh9G	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSDBxOVVIWGI4TW13dkVxZ2hXS3VjUkFRY0NhNXRybHdaQnNZMkJHSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761835802
oPNceFxCRTYX336a2UYwcio17RcxxIcWXARWs9er	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVktQZERrb2FBTlNXREVMSjR0eTlOTnRDcFpaMDRiWTExT01yV2RGWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761835882
gXerUyeaBJjix06A4HCmuWcrzY1FvP9aUfjJ6YWg	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibGNsTHBCVEs4QXU5YXZUaHhweXBGNFRKa2U1d3JmRHFyN0hnZkcybCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761835882
aZAXSJZIR4YmLUC16X6c9W6hyhP2PZ46qWHQUpLv	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVVlXUmpENW1HaXdsOWVtUWhwUGR5NlZxQmZmMHZ5bjZRa2VnSE91dSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761836182
LHQN6qFNlN6IPPzWELlV3qIgh1WSyZGJe27FyF2o	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ1E0Z1RodG5ONHhoNlBLM05IaGNwSDRSQ2pMN2RYeHhDOE5ZZHFHdCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761836182
kulRTO7LpDjbz5W8FVJmcJymV4rbJPMEQgOmngVw	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoia1k1YWkzUm1PVU5VazlUdzI5TVZiVjJVYkoyTW1JQTJrdzBlZTYzRyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761837685
KlIiOFpIyEXanUjqctZ5qRNhTtzOB7PVq2fHaIjC	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoidnVpWUhtZnRlTTdDaTlMWmlOVWkzVW5ZRVdreFpndWlzcUhDZEo2aCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761836401
rdcbNjJstldlaZwxElzUdAF7kdc1bBsAxqL9SE7P	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiam54aEtnemRrWkZVWFh2ZldkZkhOVVJBU0Nka1E1SlF3V1dMM3k1cyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761836482
8bEPOYtk3jDqnT3rbOvZhkC6EYJKZLu0xfmihfAf	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSThlaGZpSDNPclNmbWU2R0l0Y3NCQ2VRbUJiQnV0Y1U4dUVTS1NDNCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761836482
U92gcLUgMyDPBWDeTFt6f3mqMwDjLBshes4gpjWz	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoid2pONTRnZ29VdFNmVU9WbjMxb0Rwd0lUVDNTNUxzTDh4aUgyeTM2RCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761837383
OW8yWa49ambq5dLuqSQPyOcvfQjr3Xw0KuSQOqiG	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibnVpUUE4NVc0VG9wWUVHNWhES3Bma2U5bE9Fd2hxTmJQdlk5S1o1TyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761837985
CbjghWU77dsl2UX5hAYnOBcgtcW6nXyydPDjkt6R	6	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0	YTo2OntzOjY6Il90b2tlbiI7czo0MDoiMWxnYWVCR0x3VW9nNjhua0sxU3ZQSGVUczBSU2ZkbmthVXFFT2Z4eSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjY7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6Mjk6Imh0dHBzOi8vc3dhZWR1YWUuYWUvZGFzaGJvYXJkIjt9fQ==	1761837450
50kBtyck4UP0kzh1ZcHDvTipvPNERRvjQgNJ3FJ0	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiN2xtT1lvTXF4dTZUcDNZREV0b1pEMjBBTmNTU0d0MzlPd0pkTGlKNCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761836770
ZPuSp6QR2Hi3jQFYuqxU4UYaTFDGAWo8l0XhaBDW	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUU1ldVdlMlNTNlBGbnFqOEI3NXdLcnhxcGhncmY4dEswUGdERXNiQiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761836782
TIUnoTC1ha2s3516ZI7E8fmwzcL1T2pTrWgBXFJ8	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoidGM5eUV0SHdGbjBxbVk0Tk5mbVhhNWVxQmhtTVF3TjhjdDFMY3lnUiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761836782
x5nyFm2XLWI411BDsP6BvQF12ap20Rv2iXTHDfMJ	5	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiZFBja3YzMFdES3FsOFRwTFZKaFp3U3ZTMTMzNEEzV3hrMFd5cTNudyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6MjY6Imh0dHBzOi8vc3dhZWR1YWUuYWUvZXZlbnRzIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NTt9	1761836871
ScpPxR1Cay9SD3PqkUquISrubfuRWjXnkX2bLNqi	\N	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiM0lPT2FadjJraWJ1dFRXTzlkcjEyZGtjdm95alRoVlBVVjA0WmRXUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761837731
238cEZCnWOw1OwzXIhjWdFAsZIZ17Vbl6ancKcNU	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaFlLeFQzb1k3cDQ4RGZRSkxsbTdkOHdPR1k1cmFPeVNyNEswMmo0ViI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761838285
b4nnVGUC7mvIkiflsPmN4IwLqk5sYbInF6J4OCoU	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoidU5JRzVLVGJ2c01Sc3FEdlBCeVFZNWdrU3k4cGVnVHFXRVBiWUM5aiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761838585
ZpGPhTqjZXL04z7W82ZTQCnvNxsk6fqEIhBWvM6M	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNmdnaEtubmpoSmdVU0Q0RXFvOVQ0VTB0QVJodkl5cEF1WDZacFI2ZCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761838886
IIwZ4j4PM4O8h1AiP8PaB5t5ZQizmCrcPVgBvt9I	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoidXN6OVhXZHVTVDdrOGRJVGZJU1dOVDFrbVVrRnZIQUliOGVDMWtnYyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761839187
9AxzWJXmLDLkJaVCMPvWWKQVsLI503aCaubgYZIp	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVjVpSHBIRG02ejdVYUxrakZuSjdLaGRTTElHbFRGOUM5ZU9TREpUayI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vd3d3LnN3YWVkdWFlLmFlIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1761837082
bPdhQVvP86MZ66mBFlLTqQkWbTy5IUWJvUtRYp2t	\N	127.0.0.1	curl/7.81.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUFVNWHl5RmdYa29oZFgzMlpVVVpJT2owME1kT1VobjNURzlwbG92WCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vYWRtaW4uc3dhZWR1YWUuYWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1761837082
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.settings (id, key, value, type, "group", description, created_at, updated_at) FROM stdin;
1	site_name	"SwaedUAE"	string	general	Website name	2025-10-30 14:55:27	2025-10-30 14:55:27
2	site_description	"Volunteer Management Platform for UAE"	string	general	Website description	2025-10-30 14:55:27	2025-10-30 14:55:27
3	site_keywords	"volunteer, uae, community, service"	string	general	SEO keywords	2025-10-30 14:55:27	2025-10-30 14:55:27
4	site_logo	"\\/images\\/logo.png"	string	general	Website logo path	2025-10-30 14:55:27	2025-10-30 14:55:27
5	site_favicon	"\\/images\\/favicon.ico"	string	general	Website favicon path	2025-10-30 14:55:27	2025-10-30 14:55:27
6	maintenance_mode	"0"	boolean	general	Maintenance mode status	2025-10-30 14:55:27	2025-10-30 14:55:27
7	mail_driver	"smtp"	string	email	Mail driver	2025-10-30 14:55:27	2025-10-30 14:55:27
8	mail_host	"smtp.zoho.com"	string	email	Mail host	2025-10-30 14:55:27	2025-10-30 14:55:27
9	mail_port	"587"	integer	email	Mail port	2025-10-30 14:55:27	2025-10-30 14:55:27
10	mail_username	"admin@swaeduae.ae"	string	email	Mail username	2025-10-30 14:55:27	2025-10-30 14:55:27
11	mail_password	""	string	email	Mail password (encrypted)	2025-10-30 14:55:27	2025-10-30 14:55:27
12	mail_encryption	"tls"	string	email	Mail encryption	2025-10-30 14:55:27	2025-10-30 14:55:27
13	mail_from_address	"admin@swaeduae.ae"	string	email	Mail from address	2025-10-30 14:55:27	2025-10-30 14:55:27
14	mail_from_name	"SwaedUAE"	string	email	Mail from name	2025-10-30 14:55:27	2025-10-30 14:55:27
15	api_base_url	"https:\\/\\/api.swaeduae.ae"	string	api	API base URL	2025-10-30 14:55:27	2025-10-30 14:55:27
16	api_key	""	string	api	API key	2025-10-30 14:55:27	2025-10-30 14:55:27
17	api_secret	""	string	api	API secret	2025-10-30 14:55:27	2025-10-30 14:55:27
18	google_maps_api_key	""	string	api	Google Maps API key	2025-10-30 14:55:27	2025-10-30 14:55:27
19	firebase_api_key	""	string	api	Firebase API key	2025-10-30 14:55:27	2025-10-30 14:55:27
20	facebook_url	"https:\\/\\/facebook.com\\/swaeduae"	string	social	Facebook URL	2025-10-30 14:55:27	2025-10-30 14:55:27
21	twitter_url	"https:\\/\\/twitter.com\\/swaeduae"	string	social	Twitter URL	2025-10-30 14:55:27	2025-10-30 14:55:27
22	instagram_url	"https:\\/\\/instagram.com\\/swaeduae"	string	social	Instagram URL	2025-10-30 14:55:27	2025-10-30 14:55:27
23	linkedin_url	"https:\\/\\/linkedin.com\\/company\\/swaeduae"	string	social	LinkedIn URL	2025-10-30 14:55:27	2025-10-30 14:55:27
24	primary_color	"#dc2626"	string	appearance	Primary color	2025-10-30 14:55:27	2025-10-30 14:55:27
25	secondary_color	"#2563eb"	string	appearance	Secondary color	2025-10-30 14:55:27	2025-10-30 14:55:27
26	site_language	"en"	string	appearance	Default language	2025-10-30 14:55:27	2025-10-30 14:55:27
\.


--
-- Data for Name: user_badges; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.user_badges (id, user_id, badge_id, earned_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: swaeduae_user
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at, phone, date_of_birth, gender, nationality, emirates_id, address, city, emirate, postal_code, emergency_contact_name, emergency_contact_phone, emergency_contact_relationship, skills, interests, bio, avatar, languages, education_level, occupation, has_transportation, availability, total_volunteer_hours, total_events_attended, points, is_verified, verified_at, profile_completed, notification_preferences, privacy_settings, last_active_at, unique_id) FROM stdin;
1	Hamad Alshehyari	alsadi22@gmail.com	\N	$2y$12$.LAjvvpih12YOaKSIs0Ky.jhts81l0R8CN1WHAH4TrWx7/2ejw/KO	\N	2025-10-30 14:53:32	2025-10-30 14:53:32	0501821117	1987-06-14	male	uae	\N	JVT district 2 Villa G56\r\nDubai	Dubai	dubai	\N	\N	\N	\N	\N	\N	\N	\N	\N	high_school	\N	t	\N	0.00	0	0	f	\N	f	\N	\N	\N	SV000001
2	Admin User	admin@swaeduae.ae	2025-10-30 14:55:27	$2y$12$e49aCAZRVQDtugk0X/uryeRO1Tq3PiqHTkoQt2HbAEJZJVd5tZ9Bu	\N	2025-10-30 14:55:27	2025-10-30 14:55:27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0.00	0	0	f	\N	f	\N	\N	\N	ADMIN69037C5FC0F28
3	Test Volunteer	volunteer@swaeduae.ae	2025-10-30 14:55:27	$2y$12$IBUcKQujLjRydLZVsgKxZOxwuZrgu0cE0o0Xpe7ZU5lDTIixlrm1O	\N	2025-10-30 14:55:27	2025-10-30 14:55:27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0.00	0	0	f	\N	f	\N	\N	\N	VOL69037C5FEF522
4	Organization Manager	org@swaeduae.ae	2025-10-30 14:55:27	$2y$12$YoVTd82yMTd6B6HOggpQc.DNYi8rVdWy8xO1yYjDl8DjKzCE8Nyb.	\N	2025-10-30 14:55:28	2025-10-30 14:55:28	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0.00	0	0	f	\N	f	\N	\N	\N	ORG69037C60290C8
5	Hamad Alshehyari	alsadi2234@gmail.com	\N	$2y$12$MtoTvR70/GYlijSyk9TM9uOk9QJgL6Coq6ZY3S07Z7ldJSSVBiVim	\N	2025-10-30 14:56:23	2025-10-30 14:56:23	0501821117	1987-06-14	male	uae	\N	JVT district 2 Villa G56\r\nDubai	Dubai	dubai	\N	\N	\N	\N	\N	\N	\N	\N	\N	high_school	\N	t	\N	0.00	0	0	f	\N	f	\N	\N	\N	SV000005
6	swaeduae	alsadi44444@gmail.com	\N	$2y$12$faFqeL3svj0ElPATLCSEHeD3sRVR1LxSV9c.2fxV0oyI4juSWAyym	\N	2025-10-30 15:11:57	2025-10-30 15:11:57	+971501821117	1997-10-14	male	uae	\N	\N	dubai	dubai	\N	\N	\N	\N	\N	\N	\N	\N	\N	high_school	\N	t	\N	0.00	0	0	f	\N	f	\N	\N	\N	SV000006
\.


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.announcements_id_seq', 1, false);


--
-- Name: applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.applications_id_seq', 1, false);


--
-- Name: attendances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.attendances_id_seq', 1, false);


--
-- Name: badge_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.badge_progress_id_seq', 1, false);


--
-- Name: badges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.badges_id_seq', 6, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, false);


--
-- Name: certificates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.certificates_id_seq', 1, false);


--
-- Name: emergency_communications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.emergency_communications_id_seq', 1, false);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.events_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.migrations_id_seq', 46, true);


--
-- Name: organization_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.organization_users_id_seq', 1, false);


--
-- Name: organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.organizations_id_seq', 1, false);


--
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.pages_id_seq', 11, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.permissions_id_seq', 47, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.roles_id_seq', 6, true);


--
-- Name: scheduled_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.scheduled_reports_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.settings_id_seq', 26, true);


--
-- Name: user_badges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.user_badges_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swaeduae_user
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: applications applications_user_id_event_id_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_user_id_event_id_unique UNIQUE (user_id, event_id);


--
-- Name: attendances attendances_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_pkey PRIMARY KEY (id);


--
-- Name: attendances attendances_user_id_event_id_application_id_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_user_id_event_id_application_id_unique UNIQUE (user_id, event_id, application_id);


--
-- Name: badge_progress badge_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.badge_progress
    ADD CONSTRAINT badge_progress_pkey PRIMARY KEY (id);


--
-- Name: badge_progress badge_progress_user_id_badge_id_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.badge_progress
    ADD CONSTRAINT badge_progress_user_id_badge_id_unique UNIQUE (user_id, badge_id);


--
-- Name: badges badges_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_pkey PRIMARY KEY (id);


--
-- Name: badges badges_slug_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_slug_unique UNIQUE (slug);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: certificates certificates_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: certificates certificates_verification_code_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_verification_code_unique UNIQUE (verification_code);


--
-- Name: emergency_communications emergency_communications_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.emergency_communications
    ADD CONSTRAINT emergency_communications_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: events events_slug_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_slug_unique UNIQUE (slug);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- Name: organization_users organization_users_organization_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_organization_id_user_id_unique UNIQUE (organization_id, user_id);


--
-- Name: organization_users organization_users_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_email_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_email_unique UNIQUE (email);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_slug_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_slug_unique UNIQUE (slug);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_slug_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_unique UNIQUE (slug);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: permissions permissions_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- Name: roles roles_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: scheduled_reports scheduled_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.scheduled_reports
    ADD CONSTRAINT scheduled_reports_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_key_unique UNIQUE (key);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: user_badges user_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_pkey PRIMARY KEY (id);


--
-- Name: user_badges user_badges_user_id_badge_id_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_user_id_badge_id_unique UNIQUE (user_id, badge_id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_emirates_id_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_emirates_id_unique UNIQUE (emirates_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_unique_id_unique; Type: CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_unique_id_unique UNIQUE (unique_id);


--
-- Name: announcements_created_by_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX announcements_created_by_index ON public.announcements USING btree (created_by);


--
-- Name: announcements_event_id_is_published_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX announcements_event_id_is_published_index ON public.announcements USING btree (event_id, is_published);


--
-- Name: announcements_organization_id_is_published_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX announcements_organization_id_is_published_index ON public.announcements USING btree (organization_id, is_published);


--
-- Name: applications_event_id_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX applications_event_id_index ON public.applications USING btree (event_id);


--
-- Name: applications_status_applied_at_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX applications_status_applied_at_index ON public.applications USING btree (status, applied_at);


--
-- Name: applications_user_id_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX applications_user_id_index ON public.applications USING btree (user_id);


--
-- Name: attendances_checked_in_at_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX attendances_checked_in_at_index ON public.attendances USING btree (checked_in_at);


--
-- Name: attendances_checked_out_at_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX attendances_checked_out_at_index ON public.attendances USING btree (checked_out_at);


--
-- Name: attendances_event_id_status_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX attendances_event_id_status_index ON public.attendances USING btree (event_id, status);


--
-- Name: attendances_user_id_event_id_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX attendances_user_id_event_id_index ON public.attendances USING btree (user_id, event_id);


--
-- Name: badges_type_is_active_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX badges_type_is_active_index ON public.badges USING btree (type, is_active);


--
-- Name: categories_is_active_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX categories_is_active_index ON public.categories USING btree (is_active);


--
-- Name: categories_name_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX categories_name_index ON public.categories USING btree (name);


--
-- Name: certificates_certificate_number_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX certificates_certificate_number_index ON public.certificates USING btree (certificate_number);


--
-- Name: certificates_user_id_type_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX certificates_user_id_type_index ON public.certificates USING btree (user_id, type);


--
-- Name: certificates_verification_code_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX certificates_verification_code_index ON public.certificates USING btree (verification_code);


--
-- Name: emergency_communications_created_by_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX emergency_communications_created_by_index ON public.emergency_communications USING btree (created_by);


--
-- Name: emergency_communications_event_id_priority_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX emergency_communications_event_id_priority_index ON public.emergency_communications USING btree (event_id, priority);


--
-- Name: emergency_communications_organization_id_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX emergency_communications_organization_id_index ON public.emergency_communications USING btree (organization_id);


--
-- Name: events_emirate_category_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX events_emirate_category_index ON public.events USING btree (emirate, category);


--
-- Name: events_organization_id_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX events_organization_id_index ON public.events USING btree (organization_id);


--
-- Name: events_status_start_date_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX events_status_start_date_index ON public.events USING btree (status, start_date);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: messages_event_id_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX messages_event_id_index ON public.messages USING btree (event_id);


--
-- Name: messages_organization_id_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX messages_organization_id_index ON public.messages USING btree (organization_id);


--
-- Name: messages_recipient_id_is_read_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX messages_recipient_id_is_read_index ON public.messages USING btree (recipient_id, is_read);


--
-- Name: messages_sender_id_recipient_id_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX messages_sender_id_recipient_id_index ON public.messages USING btree (sender_id, recipient_id);


--
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- Name: organizations_emirate_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX organizations_emirate_index ON public.organizations USING btree (emirate);


--
-- Name: organizations_status_is_verified_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX organizations_status_is_verified_index ON public.organizations USING btree (status, is_verified);


--
-- Name: pages_is_published_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX pages_is_published_index ON public.pages USING btree (is_published);


--
-- Name: pages_slug_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX pages_slug_index ON public.pages USING btree (slug);


--
-- Name: pages_sort_order_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX pages_sort_order_index ON public.pages USING btree (sort_order);


--
-- Name: personal_access_tokens_expires_at_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX personal_access_tokens_expires_at_index ON public.personal_access_tokens USING btree (expires_at);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: settings_group_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX settings_group_index ON public.settings USING btree ("group");


--
-- Name: settings_key_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX settings_key_index ON public.settings USING btree (key);


--
-- Name: user_badges_earned_at_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX user_badges_earned_at_index ON public.user_badges USING btree (earned_at);


--
-- Name: users_emirate_city_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX users_emirate_city_index ON public.users USING btree (emirate, city);


--
-- Name: users_is_verified_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX users_is_verified_index ON public.users USING btree (is_verified);


--
-- Name: users_total_volunteer_hours_index; Type: INDEX; Schema: public; Owner: swaeduae_user
--

CREATE INDEX users_total_volunteer_hours_index ON public.users USING btree (total_volunteer_hours);


--
-- Name: announcements announcements_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: announcements announcements_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: announcements announcements_organization_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_organization_id_foreign FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: applications applications_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: applications applications_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: applications applications_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: attendances attendances_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.applications(id) ON DELETE CASCADE;


--
-- Name: attendances attendances_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: attendances attendances_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: attendances attendances_verified_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_verified_by_foreign FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: badge_progress badge_progress_badge_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.badge_progress
    ADD CONSTRAINT badge_progress_badge_id_foreign FOREIGN KEY (badge_id) REFERENCES public.badges(id) ON DELETE CASCADE;


--
-- Name: badge_progress badge_progress_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.badge_progress
    ADD CONSTRAINT badge_progress_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_organization_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_organization_id_foreign FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_verified_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_verified_by_foreign FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: emergency_communications emergency_communications_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.emergency_communications
    ADD CONSTRAINT emergency_communications_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: emergency_communications emergency_communications_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.emergency_communications
    ADD CONSTRAINT emergency_communications_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: emergency_communications emergency_communications_organization_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.emergency_communications
    ADD CONSTRAINT emergency_communications_organization_id_foreign FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: events events_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: events events_organization_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_organization_id_foreign FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: messages messages_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_event_id_foreign FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: messages messages_organization_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_organization_id_foreign FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: messages messages_recipient_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_recipient_id_foreign FOREIGN KEY (recipient_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_sender_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_foreign FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: organization_users organization_users_organization_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_organization_id_foreign FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_users organization_users_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organizations organizations_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_badges user_badges_badge_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_badge_id_foreign FOREIGN KEY (badge_id) REFERENCES public.badges(id) ON DELETE CASCADE;


--
-- Name: user_badges user_badges_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: swaeduae_user
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict WYeH7D1CcnEEjccOWFpfonafWrMKOT1FZdizyYSTgzHV59voTQ6GXRVBuXFbEK9

